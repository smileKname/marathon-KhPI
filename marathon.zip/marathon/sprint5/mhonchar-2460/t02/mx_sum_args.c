#include <unistd.h>
#include <stdbool.h>

void mx_printchar(char c);
void mx_printint(int n);
int mx_atoi(const char *str);
bool mx_isspace(char c);

void mx_sum_args(int argc, char *argv[]) {
    if (argc <= 1) {
        return; 
    }

    int sum = 0;
    for (int i = 1; i < argc; i++) {
        int num = mx_atoi(argv[i]); 
        sum += num;
    }

    mx_printint(sum); 
    mx_printchar('\n');
}

