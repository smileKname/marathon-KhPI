int mx_tolower(int c) {
    int ic = (int)c;
    if (ic >= 65 && ic <= 90) {
        return ic + 32;
    }
    return ic;
}

