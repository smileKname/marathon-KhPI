#include <stdbool.h>

bool mx_isupper(int c) {
    int ic = (int)c;
    
    if (ic >= 65 && ic <= 90) {
        return 1;
    }
    return 0;
}

