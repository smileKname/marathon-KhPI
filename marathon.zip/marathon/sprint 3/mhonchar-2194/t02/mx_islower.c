#include <stdbool.h>

bool mx_islower(int c) {
    int ic = (int)c;
    
    if (ic >= 97 && ic <= 122) {
        return 1;
    }
    return 0;
}

