#include <stdbool.h>

bool mx_islower(int c);
bool mx_isupper(int c);
int mx_tolower(int c);
int mx_toupper(int c);

void mx_reverse_case(char *c) {
    if (c == 0)
        return;

    for (int i = 0; c[i] != '\0'; i++) {
        if (mx_islower(c[i])) {
            c[i] = mx_toupper(c[i]);
        } else if (mx_isupper(c[i])) {
            c[i] = mx_tolower(c[i]);
        }
    }
}

