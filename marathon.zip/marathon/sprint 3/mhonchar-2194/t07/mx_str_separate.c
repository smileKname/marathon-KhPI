void mx_printchar(char c);
void mx_str_separate(const char *str, char del) {
    if (str == 0)
        return;

    while (*str) {
        if (*str == del) {
            mx_printchar('\n');
        } else {
            mx_printchar(*str);
        }
        str++;
    }
    mx_printchar('\n'); 
}

