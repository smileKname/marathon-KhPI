double mx_pow(double n, int pow) {
    double result = 1;

    if (pow < 0) {
        return 0; 
    }

    for (int i = 0; i < pow; i++) {
        result *= n;
    }

    return result;
}

