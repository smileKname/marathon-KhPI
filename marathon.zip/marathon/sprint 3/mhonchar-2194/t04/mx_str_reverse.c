int mx_strlen(const char *s);
void mx_swap_char(char *s1, char *s2);

void mx_str_reverse(char *s) {
    if (s == 0)
        return;

    int len = mx_strlen(s);
    char *start = s;
    char *finish = s + len - 1;

    while (start < finish) {
        mx_swap_char(start, finish);
        start++;
        finish--;
    }
}

