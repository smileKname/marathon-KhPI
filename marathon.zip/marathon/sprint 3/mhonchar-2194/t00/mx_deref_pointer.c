void mx_deref_pointer(char ******str) {
    *****str = "Follow the white rabbit!";
}

