char *mx_strcpy(char *dst, const char *src) {
    char *dest = dst; 

    while ((*dest++ = *src++) != '\0') {
    }

    return dst; 
}

