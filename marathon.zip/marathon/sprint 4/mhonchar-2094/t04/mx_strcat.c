int mx_strlen(const char *s);
char *mx_strcat(char *s1, const char *s2) {
    int s1_len = mx_strlen(s1); // Get the length of s1
    int i = 0;

    while (s2[i] != '\0') {
        s1[s1_len + i] = s2[i];
        i++;
    }

    s1[s1_len + i] = '\0';

    return s1;
}

