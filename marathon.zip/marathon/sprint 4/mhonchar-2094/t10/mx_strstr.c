char *mx_strchr(const char *s, int c);
int mx_strlen(const char *s);
int mx_strncmp(const char *s1, const char *s2, int n);

char *mx_strstr(const char *s1, const char *s2) {
    int len2 = mx_strlen(s2); 

    for (int i = 0; s1[i] != '\0'; i++) {
        if (mx_strncmp(&s1[i], s2, len2) == 0) { 
            return (char *)&s1[i];
        }
    }

    return 0; 
}
