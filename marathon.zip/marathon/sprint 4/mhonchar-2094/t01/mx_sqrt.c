int mx_sqrt(int x) {
    if (x < 0) {
        return 0;
    }

    for (int i = 1; i <= x / 2 + 1; i++) {
        if (i * i == x) {
            return i;
        } else if (i * i > x) {
            break; 
        }
    }

    return 0; 
}

