#include <stdbool.h>

bool mx_isalpha(int a) {
    int ia = (int)a;
    
    if ((ia >= 65 && ia <= 90) || (ia >= 97 && ia <= 122)) {
        return 1;
    }
    return 0;
}

